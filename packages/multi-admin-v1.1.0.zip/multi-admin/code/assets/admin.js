/* multi-admin 插件 v1.1 —— 后台「多账号管理」页 + 侧栏菜单（自包含） */
(function () {
  'use strict';
  var API = window.AdminAPI;
  var U = window.AdminU;
  var App = window.AdminApp;
  if (!API || !U) { return; }

  function esc(s) { return U.esc(s); }
  function stateBox(title, sub) {
    return '<div class="state"><b>' + esc(title) + '</b>' + (sub ? '<br>' + esc(sub) : '') + '</div>';
  }
  function fld(label, inputHtml, hint) {
    return '<div class="fld"><label>' + esc(label) + '</label>' + inputHtml +
           (hint ? '<div class="hint">' + esc(hint) + '</div>' : '') + '</div>';
  }
  function msg(boxId, text, ok) {
    var box = document.getElementById(boxId);
    if (!box) { return; }
    box.style.display = '';
    box.textContent = text;
    box.style.borderLeftColor = ok ? 'var(--accent)' : '#d64545';
  }

  var admins = {
    title: '多账号管理',
    render: function (host) {
      host.innerHTML = stateBox('加载中', '正在读取管理员列表');
      function load() {
        API.get('/plugin/multi-admin/admins').then(function (r) {
          var items = (r.data || r).items || [];
          var rows = items.map(function (a) {
            var roleTag = a.role === 'owner'
              ? '<span class="badge badge--accent">店主</span>' : '<span class="badge">店员</span>';
            var statusTag = a.status === 'active'
              ? '<span class="badge badge--ok">启用</span>' : '<span class="badge badge--warn">停用</span>';
            return '<tr>' +
              '<td class="tbl__name"><b>' + esc(a.username) + '</b><div class="tbl__sub">' + esc(a.display_name || '') + '</div></td>' +
              '<td>' + esc(a.email || '—') + '</td>' +
              '<td>' + roleTag + '</td>' +
              '<td>' + statusTag + '</td>' +
              '<td>' + esc((a.last_login_at || '从未登录').replace('T', ' ')) + '</td>' +
              '<td class="tbl__actions">' +
                '<button class="btn btn--sm btn--ghost" data-act="edit" data-id="' + a.id + '">编辑</button> ' +
                '<button class="btn btn--sm btn--ghost" data-act="reset" data-id="' + a.id + '">重置密码</button> ' +
                '<button class="btn btn--sm btn--ghost" data-act="toggle" data-id="' + a.id + '" data-status="' + esc(a.status) + '">' + (a.status === 'active' ? '停用' : '启用') + '</button> ' +
                '<button class="btn btn--sm btn--ghost" data-act="del" data-id="' + a.id + '">删除</button>' +
              '</td>' +
            '</tr>';
          }).join('');
          host.innerHTML =
            '<div class="panel-card">' +
              '<div class="panel-card__head"><h2>后台管理员账号</h2><span class="spacer"></span>' +
                '<button class="btn btn--primary btn--sm" id="admin-add" type="button">新增管理员</button></div>' +
              '<div class="panel-card__body">' +
                '<div class="notice" style="margin-top:0;margin-bottom:16px"><span>' +
                  '店主可新增多个店员账号分担管理。新增 / 重置会得到一次性密码，请立即复制保存——关闭后不再显示。' +
                  '不能删除或停用当前账号与最后一个店主。' +
                '</span></div>' +
                '<div id="admin-msg" class="notice" style="display:none"></div>' +
                '<div class="tbl-wrap"><table class="tbl"><thead><tr>' +
                  '<th>账号</th><th>邮箱</th><th>角色</th><th>状态</th><th>最近登录</th><th>操作</th>' +
                '</tr></thead><tbody>' + rows + '</tbody></table></div>' +
              '</div>' +
            '</div>';
          bind(load);
        }).catch(function (err) {
          host.innerHTML = stateBox('无法读取管理员列表', err.message || '请确认 multi-admin 插件已启用');
        });
      }
      function bind(load) {
        document.getElementById('admin-add').addEventListener('click', function () { openEditor(null, load); });
        host.querySelectorAll('button[data-act]').forEach(function (b) {
          b.addEventListener('click', function () {
            var id = parseInt(b.getAttribute('data-id'), 10);
            var act = b.getAttribute('data-act');
            if (act === 'edit') { openEditor(id, load); return; }
            if (act === 'reset') {
              if (!U.confirm('确定重置该管理员密码？其现有会话会全部失效。')) return;
              API.post('/plugin/multi-admin/admins/' + id + '/reset-password', {}).then(function (r) {
                var d = r.data || r;
                U.toast('一次性密码：' + (d.new_password || ''), 'success');
                window.alert('密码已重置\n\n账号：' + (d.username || '') + '\n一次性密码：' + (d.new_password || '') +
                  '\n\n请立即复制保存，此密码只显示这一次。首次登录后系统会要求修改。');
                load();
              }).catch(function (e) { msg('admin-msg', e.message || '操作失败', false); });
            } else if (act === 'toggle') {
              var next = b.getAttribute('data-status') === 'active' ? 'disabled' : 'active';
              API.post('/plugin/multi-admin/admins/' + id + '/status', { status: next }).then(function () { load(); })
                .catch(function (e) { msg('admin-msg', e.message || '操作失败', false); });
            } else if (act === 'del') {
              if (!U.confirm('确定删除该管理员？此操作不可恢复。')) return;
              API.del('/plugin/multi-admin/admins/' + id).then(function () { load(); })
                .catch(function (e) { msg('admin-msg', e.message || '操作失败', false); });
            }
          });
        });
      }
      function openEditor(id, load) {
        API.get('/plugin/multi-admin/admins').then(function (r) {
          var items = (r.data || r).items || [];
          var a = id ? items.find(function (x) { return x.id === id; }) : null;
          var isEdit = !!a;
          var mask = document.createElement('div');
          mask.className = 'drawer-mask';
          mask.innerHTML =
            '<div class="drawer">' +
              '<div class="drawer__head"><h2>' + (isEdit ? '编辑管理员' : '新增管理员') + '</h2>' +
                '<button class="icon-btn" data-close type="button">×</button></div>' +
              '<div class="drawer__body">' +
                (isEdit ? '' : fld('账号', '<input class="field" id="ae-user" maxlength="32" placeholder="3–32 位小写字母/数字/点/下划线/连字符">')) +
                fld('显示名称', '<input class="field" id="ae-display" maxlength="40" value="' + esc(a ? a.display_name : '') + '">') +
                fld('登录邮箱', '<input class="field" id="ae-email" maxlength="128" value="' + esc(a ? (a.email || '') : '') + '" placeholder="用于邮箱验证码登录，可留空">') +
                fld('角色', '<select class="field" id="ae-role">' +
                  '<option value="staff"' + (!a || a.role === 'staff' ? ' selected' : '') + '>店员</option>' +
                  '<option value="owner"' + (a && a.role === 'owner' ? ' selected' : '') + '>店主</option></select>') +
                '<div id="ae-err" class="notice" style="display:none"></div>' +
              '</div>' +
              '<div class="drawer__foot">' +
                '<button class="btn btn--ghost" data-close type="button">取消</button>' +
                '<button class="btn btn--primary" id="ae-save" type="button">保存</button>' +
              '</div>' +
            '</div>';
          document.body.appendChild(mask);
          // v1.1 修复：抽屉需要 is-on 类才会显示（CSS 默认 opacity:0 / translateX(102%)）
          var drawerEl = mask.querySelector('.drawer');
          if (drawerEl) { drawerEl.classList.add('is-on'); }
          mask.classList.add('is-on');
          function close() { mask.remove(); }
          mask.querySelectorAll('[data-close]').forEach(function (b) { b.addEventListener('click', close); });
          document.getElementById('ae-save').addEventListener('click', function () {
            var data = {
              display_name: document.getElementById('ae-display').value.trim(),
              email: document.getElementById('ae-email').value.trim(),
              role: document.getElementById('ae-role').value
            };
            if (!isEdit) { data.username = document.getElementById('ae-user').value.trim(); }
            var btn = this; btn.disabled = true;
            var call = isEdit ? API.put('/plugin/multi-admin/admins/' + id, data) : API.post('/plugin/multi-admin/admins', data);
            call.then(function (res) {
              close();
              if (!isEdit) {
                var d = res.data || res;
                window.alert('管理员已创建\n\n账号：' + (d.username || '') + '\n一次性密码：' + (d.initial_password || '') +
                  '\n\n请立即复制保存，此密码只显示这一次。首次登录后系统会要求修改。');
              } else {
                U.toast('已保存', 'success');
              }
              load();
            }).catch(function (e) {
              var box = document.getElementById('ae-err');
              box.style.display = ''; box.textContent = (e && e.message) || '保存失败';
            }).then(function () { btn.disabled = false; });
          });
        }).catch(function (e) { msg('admin-msg', e.message || '打开编辑器失败', false); });
      }
      load();
    }
  };


  window.AdminViews = window.AdminViews || {};
  window.AdminViews.admins = admins;

  // 仅店主显示菜单（后端也会再校验一次）
  function injectMenu() {
    if (document.getElementById('plugin-nav-admins')) { return; }
    if (App && App.me && App.me.role !== 'owner') { return; }
    var anchor = document.querySelector('.side__link[data-view="settings"]');
    if (!anchor) { return; }
    var btn = document.createElement('button');
    btn.className = 'side__link';
    btn.type = 'button';
    btn.id = 'plugin-nav-admins';
    btn.setAttribute('data-view', 'admins');
    btn.innerHTML = '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="9" r="3"/><path d="M3.5 19c0-3 2.5-5 5.5-5s5.5 2 5.5 5M16 9h5M18.5 6.5v5"/></svg>多账号管理';
    anchor.parentNode.insertBefore(btn, anchor);
  }
  injectMenu();
})();
