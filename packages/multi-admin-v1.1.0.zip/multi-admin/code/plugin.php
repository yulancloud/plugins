<?php
/**
 * multi-admin 插件 v1.1 —— 入口声明
 * 全部逻辑自带（lib.php + routes.php），系统主程序不认识多管理员功能。
 */
if (!defined('MULTI_ADMIN_DIR')) {
    define('MULTI_ADMIN_DIR', dirname(__DIR__));
}
require_once __DIR__ . '/lib.php';

return [
    'routes' => [
        ['method' => 'GET',    'path' => '/api/admin/plugin/multi-admin/admins',                 'file' => 'routes.php', 'auth' => 'owner'],
        ['method' => 'POST',   'path' => '/api/admin/plugin/multi-admin/admins',                 'file' => 'routes.php', 'auth' => 'owner'],
        ['method' => 'POST',   'path' => '/api/admin/plugin/multi-admin/admins/<id>/status',     'file' => 'routes.php', 'auth' => 'owner'],
        ['method' => 'POST',   'path' => '/api/admin/plugin/multi-admin/admins/<id>/reset-password','file' => 'routes.php', 'auth' => 'owner'],
        ['method' => 'PUT',    'path' => '/api/admin/plugin/multi-admin/admins/<id>',            'file' => 'routes.php', 'auth' => 'owner'],
        ['method' => 'DELETE', 'path' => '/api/admin/plugin/multi-admin/admins/<id>',            'file' => 'routes.php', 'auth' => 'owner'],
    ],
    'hooks'  => [],
    'assets' => [
        'admin' => ['assets/admin.js'],
    ],
];
