<?php
/**
 * multi-admin 插件 v1.1 —— API 路由处理器
 * PluginRuntime 注入 $ctx（含 params['id']），按 path + method 分发。
 */
if (!defined('MULTI_ADMIN_DIR')) {
    define('MULTI_ADMIN_DIR', dirname(__DIR__));
}
require_once __DIR__ . '/lib.php';

$__p      = $ctx['path'] ?? '';
$__m      = $ctx['method'] ?? 'GET';
$__id     = (int)($ctx['params']['id'] ?? 0);
$__op     = AdminAuth::requireOwner();
$__opId   = (int)$__op['id'];

$__base = '/api/admin/plugin/multi-admin/admins';

if ($__p === $__base && $__m === 'GET') {
    Response::ok(MultiAdminAccounts::list());
}

if ($__p === $__base && $__m === 'POST') {
    $body = readJsonBody();
    try {
        $r = MultiAdminAccounts::create($body, $__opId);
    } catch (RuntimeException $e) {
        Response::fail('invalid_param', $e->getMessage(), 400);
    }
    Response::ok($r);
}

if ($__p === $__base . '/' . $__id . '/status' && $__m === 'POST') {
    $body = readJsonBody();
    try {
        $r = MultiAdminAccounts::setStatus($__id, (string)($body['status'] ?? ''), $__opId);
    } catch (RuntimeException $e) {
        Response::fail('invalid_param', $e->getMessage(), 400);
    }
    Response::ok($r);
}

if ($__p === $__base . '/' . $__id . '/reset-password' && $__m === 'POST') {
    try {
        $r = MultiAdminAccounts::resetPassword($__id, $__opId);
    } catch (RuntimeException $e) {
        Response::fail('invalid_param', $e->getMessage(), 400);
    }
    Response::ok($r);
}

if ($__p === $__base . '/' . $__id && $__m === 'PUT') {
    $body = readJsonBody();
    try {
        $r = MultiAdminAccounts::update($__id, $body, $__opId);
    } catch (RuntimeException $e) {
        Response::fail('invalid_param', $e->getMessage(), 400);
    }
    Response::ok($r);
}

if ($__p === $__base . '/' . $__id && $__m === 'DELETE') {
    try {
        $r = MultiAdminAccounts::delete($__id, $__opId);
    } catch (RuntimeException $e) {
        Response::fail('invalid_param', $e->getMessage(), 400);
    }
    Response::ok($r);
}

Response::fail('not_found', '接口不存在', 404);
