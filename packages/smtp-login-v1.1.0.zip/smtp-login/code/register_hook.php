<?php
/**
 * smtp-login 插件 v1.1 —— 注册拦截钩子
 * PluginRuntime 调用时会注入 $ctx（引用，内容为注册请求 body）。
 * 校验失败用 Response::fail() 中断注册；通过则不改动 $ctx，交给 UserAuth::register。
 */
if (!defined('SMTP_LOGIN_DIR')) {
    define('SMTP_LOGIN_DIR', dirname(__DIR__));
}
require_once __DIR__ . '/lib.php';

// 未配置邮件服务器时不拦截，保持与旧版一致的注册行为
if (!SmtpLoginMail::isConfigured()) {
    return;
}

$email = strtolower(trim((string)($ctx['email'] ?? '')));
$code  = trim((string)($ctx['code'] ?? ''));

if ($email === '') {
    Response::fail('email_required', '请填写邮箱', 400);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    Response::fail('bad_email', '邮箱格式不正确', 400);
}
// 白名单：只有后台登记的邮箱才能注册
$cfg = SmtpLoginMail::loadConfig();
if (!in_array($email, $cfg['allowed_emails'], true)) {
    Response::fail('email_not_allowed', '该邮箱不在允许注册的名单中', 403);
}
if (!preg_match('/^\d{6}$/', $code)) {
    Response::fail('code_required', '请填写 6 位邮箱验证码', 400);
}
if (!SmtpLoginMail::checkRegisterCode($email, $code)) {
    Response::fail('bad_code', '验证码错误或已过期', 400);
}

// 校验通过：把 email 规范化写回 body，UserAuth::register 会存这份邮箱
$ctx['email'] = $email;
// code 字段不需要落到用户表，移除避免误用
unset($ctx['code']);
