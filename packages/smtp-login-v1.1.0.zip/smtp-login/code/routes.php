<?php
/**
 * smtp-login 插件 v1.1 —— API 路由处理器
 * PluginRuntime 分发时把 $ctx 注入本文件，按 $ctx['path'] 区分。
 */
if (!defined('SMTP_LOGIN_DIR')) {
    define('SMTP_LOGIN_DIR', dirname(__DIR__));
}
require_once __DIR__ . '/lib.php';

$__p = $ctx['path'] ?? '';

if ($__p === '/api/admin/plugin/smtp-login/settings' && $ctx['method'] === 'GET') {
    Response::ok(SmtpLoginMail::adminConfig());
}

if ($__p === '/api/admin/plugin/smtp-login/settings' && $ctx['method'] === 'PUT') {
    RateLimiter::guard('admin');
    $body = readJsonBody();
    try {
        $r = SmtpLoginMail::saveConfig($body['config'] ?? $body);
    } catch (RuntimeException $e) {
        Response::fail('invalid_config', $e->getMessage(), 400);
    }
    $op = AdminAuth::requireOwner();
    Audit::log($op['id'], $op['username'], 'mail_config_save', '', '');
    Response::ok($r);
}

if ($__p === '/api/admin/plugin/smtp-login/test' && $ctx['method'] === 'POST') {
    RateLimiter::guard('admin');
    $body = readJsonBody();
    try {
        SmtpLoginMail::sendTest((string)($body['to'] ?? ''));
    } catch (RuntimeException $e) {
        Response::fail('send_failed', $e->getMessage(), 400);
    }
    Response::ok(['ok' => true]);
}

if ($__p === '/api/console/plugin/smtp-login/send-code' && $ctx['method'] === 'POST') {
    RateLimiter::guard('read');
    $body = readJsonBody();
    $email = (string)($body['email'] ?? '');
    if (mb_strlen($email, 'UTF-8') > 200) {
        Response::fail('bad_email', '邮箱格式不正确', 400);
    }
    $r = SmtpLoginMail::sendCode($email);
    if (!$r['ok']) {
        Response::fail('send_failed', $r['message'], 400);
    }
    Response::ok(['ok' => true, 'message' => $r['message']]);
}

// 不该到这里（运行时只会在声明的路径分发过来）
Response::fail('not_found', '接口不存在', 404);
