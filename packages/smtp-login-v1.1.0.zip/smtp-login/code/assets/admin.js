/* smtp-login 插件 v1.1 —— 后台「邮件服务器配置」页 + 侧栏菜单（自包含） */
(function () {
  'use strict';
  var API = window.AdminAPI;
  var U = window.AdminU;
  var App = window.AdminApp;
  if (!API || !U) { return; }

  function esc(s) { return U.esc(s); }
  function stateBox(title, sub) {
    return '<div class="state"><b>' + esc(title) + '</b>' + (sub ? '<br>' + esc(sub) : '') + '</div>';
  }
  function fld(label, inputHtml, hint) {
    return '<div class="fld"><label>' + esc(label) + '</label>' + inputHtml +
           (hint ? '<div class="hint">' + esc(hint) + '</div>' : '') + '</div>';
  }
  function msg(boxId, text, ok) {
    var box = document.getElementById(boxId);
    if (!box) { return; }
    box.style.display = '';
    box.textContent = text;
    box.style.borderLeftColor = ok ? 'var(--accent)' : '#d64545';
  }

  var mailConfig = {
    title: '邮件服务器配置',
    render: function (host) {
      host.innerHTML = stateBox('加载中', '正在读取邮件配置');
      API.get('/plugin/smtp-login/settings').then(function (r) {
        var c = r.data || r;
        var encOptions = [
          { v: 'tls', t: 'STARTTLS（端口 587，推荐）' },
          { v: 'ssl', t: 'SSL / TLS（端口 465）' },
          { v: 'none', t: '不加密（端口 25，不推荐）' }
        ].map(function (o) {
          return '<option value="' + o.v + '"' + (c.encryption === o.v ? ' selected' : '') + '>' + esc(o.t) + '</option>';
        }).join('');
        host.innerHTML =
          '<div class="panel-card">' +
            '<div class="panel-card__head"><h2>SMTP 邮件服务器</h2></div>' +
            '<div class="panel-card__body">' +
              '<div class="notice" style="margin-top:0;margin-bottom:16px"><span>' +
                '用于用户中心「邮箱验证码注册」发信。密码只写不读：留空表示不修改已保存的密码。' +
                '需在下方登记允许注册的邮箱，只有这些邮箱能收到验证码并完成注册。' +
              '</span></div>' +
              '<form id="mail-form">' +
                '<div class="form-grid" style="grid-template-columns:1fr 1fr">' +
                  fld('SMTP 主机', '<input class="field" id="mail-host" maxlength="253" value="' + esc(c.host || '') + '" placeholder="smtp.example.com">', '如 smtp.qq.com') +
                  fld('端口', '<input class="field" id="mail-port" type="number" min="1" max="65535" value="' + esc(String(c.port || 587)) + '">', 'TLS 587 / SSL 465') +
                  fld('加密方式', '<select class="field" id="mail-enc">' + encOptions + '</select>') +
                  fld('SMTP 账号', '<input class="field" id="mail-user" maxlength="128" autocomplete="off" value="' + esc(c.username || '') + '">', '通常是完整邮箱地址') +
                  fld('SMTP 密码 / 授权码', '<input class="field" id="mail-pass" type="password" maxlength="256" autocomplete="new-password" placeholder="' + (c.password_set ? '已设置，留空保持不变' : '未设置') + '">', 'QQ/163 邮箱请填授权码') +
                  fld('发件人邮箱', '<input class="field" id="mail-from" maxlength="128" value="' + esc(c.from_email || '') + '" placeholder="留空则用 SMTP 主机">') +
                  fld('发件人名称', '<input class="field" id="mail-fromname" maxlength="60" value="' + esc(c.from_name || '') + '" placeholder="如 欲蓝财务">') +
                '</div>' +
                fld('允许注册的邮箱', '<textarea class="field" id="mail-allowed" rows="4" placeholder="每行一个邮箱">' + esc((c.allowed_emails || []).join('\n')) + '</textarea>', '只有这些邮箱能收到验证码并完成注册，每行一个，最多 50 个') +
                '<div class="toolbar" style="margin-top:14px">' +
                  '<button class="btn btn--primary" id="mail-save" type="submit">保存配置</button>' +
                  '<button class="btn btn--ghost" id="mail-test" type="button">发送测试邮件</button>' +
                '</div>' +
              '</form>' +
              '<div id="mail-result" class="notice" style="display:none"></div>' +
            '</div>' +
          '</div>';

        function collect() {
          return {
            host: document.getElementById('mail-host').value.trim(),
            port: parseInt(document.getElementById('mail-port').value, 10) || 587,
            encryption: document.getElementById('mail-enc').value,
            username: document.getElementById('mail-user').value.trim(),
            password: document.getElementById('mail-pass').value,
            from_email: document.getElementById('mail-from').value.trim(),
            from_name: document.getElementById('mail-fromname').value.trim(),
            allowed_emails: document.getElementById('mail-allowed').value.split(/\r?\n/).map(function (s) { return s.trim(); }).filter(Boolean)
          };
        }
        document.getElementById('mail-form').addEventListener('submit', function (e) {
          e.preventDefault();
          var btn = document.getElementById('mail-save');
          btn.disabled = true;
          API.put('/plugin/smtp-login/settings', { config: collect() }).then(function () {
            msg('mail-result', '配置已保存', true);
            document.getElementById('mail-pass').value = '';
          }).catch(function (err) {
            msg('mail-result', err.message || '保存失败', false);
          }).then(function () { btn.disabled = false; });
        });
        document.getElementById('mail-test').addEventListener('click', function () {
          var to = (document.getElementById('mail-allowed').value.split(/\r?\n/)[0] || '').trim();
          if (!to) { msg('mail-result', '请先填写一个允许注册的邮箱用于测试', false); return; }
          var btn = document.getElementById('mail-test');
          btn.disabled = true;
          API.post('/plugin/smtp-login/test', { to: to }).then(function () {
            msg('mail-result', '测试邮件已发送至 ' + to, true);
          }).catch(function (err) {
            msg('mail-result', '发送失败：' + (err.message || '未知错误'), false);
          }).then(function () { btn.disabled = false; });
        });
      }).catch(function (err) {
        host.innerHTML = stateBox('无法读取邮件配置', err.message || '请确认 smtp-login 插件已启用');
      });
    }
  };


  // 注册视图
  window.AdminViews = window.AdminViews || {};
  window.AdminViews.mailConfig = mailConfig;

  // 注入侧栏菜单到「系统」组（在「账号与设置」之前）
  function injectMenu() {
    if (document.getElementById('plugin-nav-mail')) { return; }
    var anchor = document.querySelector('.side__link[data-view="settings"]');
    if (!anchor) { return; }
    var btn = document.createElement('button');
    btn.className = 'side__link';
    btn.type = 'button';
    btn.id = 'plugin-nav-mail';
    btn.setAttribute('data-view', 'mailConfig');
    btn.innerHTML = '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3.5 6.5 8.5 6 8.5-6"/></svg>邮件服务器配置';
    anchor.parentNode.insertBefore(btn, anchor);
  }
  injectMenu();
})();
