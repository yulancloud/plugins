/* =============================================================
 * smtp-login 插件 v1.1 —— 用户中心注册页：邮箱验证码字段
 * 通过 window.ConsoleExt.hooks 注入，不修改系统文件。
 * 注册流程：填邮箱 → 点发送验证码 → 收 6 位码 → 填写 → 提交注册。
 * 只有后台白名单里的邮箱能收码并注册（服务端校验）。
 * ============================================================= */
(function () {
  'use strict';
  var Ext = window.ConsoleExt;
  if (!Ext) { return; }

  var emailInput = null;
  var codeInput = null;

  function makeField(label, type, placeholder, autocomplete) {
    var g = document.createElement('div');
    var lab = document.createElement('label');
    lab.className = 'auth__label';
    lab.textContent = label;
    var input = document.createElement('input');
    input.className = 'field';
    input.type = type;
    input.placeholder = placeholder || '';
    input.autocomplete = autocomplete || 'off';
    input.required = true;
    g.appendChild(lab);
    g.appendChild(input);
    return { group: g, input: input };
  }

  // 表单渲染时注入「邮箱 + 验证码」两块，仅注册模式
  Ext.hooks.authForm.push(function (form, mode, helpers) {
    if (mode !== 'register') { return; }

    var ef = makeField('邮箱（用于接收验证码）', 'email', '输入你已登记的邮箱', 'email');
    emailInput = ef.input;
    form.appendChild(ef.group);

    var cf = makeField('邮箱验证码', 'text', '6 位验证码', 'one-time-code');
    codeInput = cf.input;
    codeInput.maxLength = 6;
    codeInput.inputMode = 'numeric';
    codeInput.pattern = '[0-9]*';
    // 验证码行：输入框 + 发送按钮
    var row = document.createElement('div');
    row.style.display = 'flex';
    row.style.gap = '8px';
    row.style.alignItems = 'stretch';
    codeInput.style.flex = '1';
    codeInput.style.minWidth = '0';
    var sendBtn = document.createElement('button');
    sendBtn.type = 'button';
    sendBtn.className = 'btn btn--ghost';
    sendBtn.textContent = '发送验证码';
    sendBtn.style.whiteSpace = 'nowrap';
    row.appendChild(codeInput);
    row.appendChild(sendBtn);
    cf.group.appendChild(row);
    form.appendChild(cf.group);

    var hint = document.createElement('p');
    hint.className = 'auth__hint';
    hint.textContent = '只有站点登记过的邮箱才能接收验证码并完成注册。';
    form.appendChild(hint);

    var cool = 0;
    sendBtn.addEventListener('click', function () {
      var email = (emailInput.value || '').trim();
      if (!email) { helpers.err('请先填写邮箱'); emailInput.focus(); return; }
      var now = Date.now();
      if (now < cool) { helpers.err('发送过于频繁，请稍后再试'); return; }
      sendBtn.disabled = true;
      var old = sendBtn.textContent;
      sendBtn.textContent = '发送中…';
      fetch(new URL('../api/console/plugin/smtp-login/send-code', location.href).toString(), {
        method: 'POST', credentials: 'same-origin', cache: 'no-store',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'Origin': location.origin },
        body: JSON.stringify({ email: email })
      }).then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok) { throw new Error((j && j.error && j.error.message) || '发送失败'); }
          helpers.err('');
          cool = Date.now() + 60000;
          sendBtn.textContent = '已发送';
          codeInput.focus();
        });
      }).catch(function (e) {
        helpers.err(e.message || '发送失败');
      }).then(function () {
        sendBtn.disabled = false;
        sendBtn.textContent = old;
      });
    });
  });

  // 提交前把邮箱 + 验证码塞进 payload，交给服务端注册钩子校验
  Ext.hooks.beforeSubmit.push(function (payload, mode, form) {
    if (mode !== 'register') { return true; }
    payload.email = (emailInput && emailInput.value || '').trim();
    payload.code = (codeInput && codeInput.value || '').trim();
    return true;
  });
})();
