<?php
/**
 * smtp-login 插件 v1.1 —— 入口声明
 * 所有逻辑自带，不依赖系统底座。系统只需 PluginRuntime 加载本文件。
 * 注册验证：用户中心注册需填邮箱 + 验证码，只有白名单邮箱能收码并注册。
 */
if (!defined('SMTP_LOGIN_DIR')) {
    define('SMTP_LOGIN_DIR', dirname(__DIR__));
}
require_once __DIR__ . '/lib.php';

return [
    'routes' => [
        ['method' => 'GET',  'path' => '/api/admin/plugin/smtp-login/settings',   'file' => 'routes.php', 'auth' => 'owner'],
        ['method' => 'PUT',  'path' => '/api/admin/plugin/smtp-login/settings',   'file' => 'routes.php', 'auth' => 'owner'],
        ['method' => 'POST', 'path' => '/api/admin/plugin/smtp-login/test',       'file' => 'routes.php', 'auth' => 'owner'],
        ['method' => 'POST', 'path' => '/api/console/plugin/smtp-login/send-code','file' => 'routes.php', 'auth' => ''],
    ],
    'hooks' => [
        'console.register' => 'register_hook.php',
    ],
    'assets' => [
        'console' => ['assets/console.js'],
        'admin'   => ['assets/admin.js'],
    ],
];
