/* 登录页深色模式（插件前端示例，v1.2.1 已内置注入） */
(function(){
  var KEY='shiwu-theme';
  function apply(t){document.documentElement.setAttribute('data-theme',t);
    try{localStorage.setItem(KEY,t);}catch(e){}}
  var saved=null; try{saved=localStorage.getItem(KEY);}catch(e){}
  if(saved==='dark'||saved==='light'){apply(saved);}
  else if(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches){apply('dark');}
})();
