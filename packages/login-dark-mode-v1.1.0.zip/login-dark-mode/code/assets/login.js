/* login-dark-mode 插件 v1.1 —— 登录页右上角明暗切换按钮 */
(function () {
  'use strict';
  if (document.getElementById('login-theme-toggle')) { return; }

  var KEY = 'shiwu-theme';
  function current() {
    try { return localStorage.getItem(KEY) || 'light'; } catch (e) { return 'light'; }
  }
  function apply(mode) {
    document.documentElement.setAttribute('data-theme', mode);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) { meta.setAttribute('content', mode === 'dark' ? '#11141a' : '#f5f6f8'); }
  }
  apply(current());

  var btn = document.createElement('button');
  btn.id = 'login-theme-toggle';
  btn.className = 'icon-btn';
  btn.type = 'button';
  btn.setAttribute('aria-label', '切换深色模式');
  btn.title = '切换深色模式';
  btn.style.cssText = 'position:absolute;top:20px;right:20px;z-index:2;';
  btn.innerHTML = '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 9 9 7 7 0 0 1-9-9Z"/></svg>';
  btn.addEventListener('click', function () {
    var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    apply(next);
    try { localStorage.setItem(KEY, next); } catch (e) {}
  });

  var wrap = document.querySelector('.login-wrap');
  if (wrap) { wrap.appendChild(btn); }
})();
