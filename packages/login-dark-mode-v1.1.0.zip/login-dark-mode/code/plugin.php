<?php
/**
 * login-dark-mode 插件 v1.1 —— 登录页深色模式（自包含）
 * 通过 PluginRuntime 注入 login 槽位的脚本实现明暗切换，不依赖系统内置 UI。
 */
return [
    'routes' => [],
    'hooks'  => [],
    'assets' => [
        'login' => ['assets/login.js'],
    ],
];
