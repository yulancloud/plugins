# 安装说明 · Hello 示例插件

> 第一次装插件？照着做就行，全程约 3 分钟。这个插件**不会改动系统任何原有文件**，装坏了直接删掉文件夹即可。

## 适用版本

- 欲蓝财务商城系统 v1.1.0 及以上（访问 `/api/health`，返回里的 `build` 是 `20261115a` 或更新）
- PHP ≥ 8.1
- 网站运行目录已经指向 `public/`（不知道怎么确认，看 [部署总览](https://doc.yulancloud.us.ci/deploy)）

## ① 备份（一定要做）

在网站根目录执行：

```bash
cp -r config config.bak-$(date +%Y%m%d-%H%M)
cp data/shop.sqlite data/shop.sqlite.bak-$(date +%Y%m%d-%H%M)
```

用宝塔 / FTP 的话，把整个网站目录打包下载到本机一份也行。

## ② 下载并解压

从 [插件市场](https://yulancloud.us.ci/market/) 下载 `hello-world-v1.0.0.zip`，解压后你会看到：

```
hello-world/
├── plugin.json
├── INSTALL.md        ← 本文件
├── README.md
├── files/
│   └── public/
│       └── plugins/
│           └── hello/
│               └── index.html
└── assets/icon.svg
```

## ③ 复制文件（整个安装只有这一步）

把 `files/public/plugins/hello/` 这个 **hello 文件夹整体**复制到网站的 `public/plugins/` 下面，最终路径是：

```
你的网站目录/public/plugins/hello/index.html
```

- 命令行：`mkdir -p /你的网站目录/public/plugins && cp -r files/public/plugins/hello /你的网站目录/public/plugins/`
- 宝塔 / FTP：在 `public/` 下新建 `plugins` 文件夹，再把 `hello` 文件夹拖进去

> ⚠️ 不要多套一层目录。错成 `public/plugins/hello/hello/index.html` 会打不开。
> `files/` 里的路径是相对**项目根目录**（`public/` 的上一级）写的，照原样复制即可。

## ④ 不用跑迁移、不用改版本号

本插件只新增一个独立页面：

- ❌ 不建表、不加字段 → **不用**跑 `php bin/migrate.php`
- ❌ 不改已有 HTML 里的 JS/CSS 引用 → **不用** bump `?v=` 版本号
- ❌ 不改 `config/`、`public/api/index.php` 等任何核心文件

> 其它插件如果要求跑迁移或合并代码，会以它自己的 `INSTALL.md` 为准，见 [通用安装教程](https://doc.yulancloud.us.ci/plugins/install)。

## ⑤ 验证

浏览器打开：

```
https://你的域名/plugins/hello/
```

看到写着「插件装好了 🎉」的页面就成功了。再回商城首页点几下，确认原功能没受影响。

## ⑥ 卸载 / 回滚

- **卸载**：删掉 `public/plugins/hello/` 整个文件夹即可，系统其它文件一个字都不用改。
- **回滚**：把第 ① 步的备份覆盖回去。

## 常见问题

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| 打开 `/plugins/hello/` 是 404 | 运行目录没指向 `public/`，或文件放错层级 | 看 [部署总览](https://doc.yulancloud.us.ci/deploy)，确认运行目录；检查路径是不是多套了一层 `hello` |
| 页面打开了但没有样式 | `../../assets/style.css` 没找到 | 确认商城 `public/assets/style.css` 存在；升级过系统的话清一下浏览器与 CDN 缓存 |
| 页面显示但商城首页打不开 | 与本插件无关 | 用第 ① 步备份还原，再看 [部署与迁移故障](https://doc.yulancloud.us.ci/troubleshoot/deploy) |
