# Hello 示例插件

欲蓝财务插件市场的**零依赖示例插件**，用来演示插件包长什么样、以及完整安装流程。

装上后访问 `/plugins/hello/` 会看到一个独立页面，仅此而已。它：

- 只新增 `public/plugins/hello/index.html` 一个文件
- 不改任何核心文件、不建表、不跑迁移、不用 bump `?v=` 版本号
- 卸载 = 删掉这个文件夹

## 立即体验

1. 去 [插件市场](https://yulancloud.us.ci/market/) 下载 `hello-world-v1.0.0.zip`
2. 按包内 `INSTALL.md`（或 [小白安装教程](https://doc.yulancloud.us.ci/plugins/install)）走一遍
3. 打开 `https://你的域名/plugins/hello/`

## 想做自己的插件？

用 [插件开发模板仓库](https://github.com/yulancloud/plugin-template) 点 `Use this template` 一键建仓，照 [功能自定义教程](https://doc.yulancloud.us.ci/developer/custom) 加功能，打包后到市场点「上传插件」提交。
